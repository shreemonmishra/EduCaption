function generateRecap(transcript) {
    const sentences = transcript.match(/[^.!?]+[.!?]/g) || [];
    let recap = [];

    for (let i = 0; i < sentences.length; i++) {
        if (i % 5 === 0) {
            recap.push(sentences[i].trim());
        }
    }

    return recap.join(" ");
}

module.exports = { generateRecap };