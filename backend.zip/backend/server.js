require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { connectMongoDB } = require('./config/db');

const app = express();

app.use(cors());
app.use(express.json());

// connect DBs (Mongo optional, SQLite always)
connectMongoDB();

// root
app.get('/', (_req, res) => res.send('Backend is running ✅'));

// api routes
app.use('/api', require('./routes/api'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));